namespace AudioTranscriptionAssessment.Models;

public sealed record TranscriptionSegment(
    int Index,
    double StartSeconds,
    double EndSeconds,
    string Text);
