namespace AudioTranscriptionAssessment.Models;

public sealed record TranscriptionResult(
    string SourceFile,
    string Language,
    string Model,
    DateTimeOffset CreatedAtUtc,
    double DurationSeconds,
    string Text,
    IReadOnlyList<TranscriptionSegment> Segments);
