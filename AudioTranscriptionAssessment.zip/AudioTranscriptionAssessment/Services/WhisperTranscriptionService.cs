using AudioTranscriptionAssessment.Models;
using Whisper.net;

namespace AudioTranscriptionAssessment.Services;

public sealed class WhisperTranscriptionService
{
    private readonly FfmpegAudioPreprocessor _preprocessor;
    private readonly string _modelPath;
    private readonly int _chunkDurationSeconds;

    public WhisperTranscriptionService(
        FfmpegAudioPreprocessor preprocessor,
        string modelPath,
        int chunkDurationSeconds = 600)
    {
        _preprocessor = preprocessor;
        _modelPath = Path.GetFullPath(modelPath);
        _chunkDurationSeconds = chunkDurationSeconds;
    }

    public async Task<TranscriptionResult> TranscribeAsync(
        string audioPath,
        string language = "auto",
        CancellationToken cancellationToken = default)
    {
        audioPath = Path.GetFullPath(audioPath);
        if (!File.Exists(audioPath))
            throw new FileNotFoundException("Audio file was not found.", audioPath);
        if (!File.Exists(_modelPath))
            throw new FileNotFoundException(
                "Whisper model file was not found. Download a GGML model and pass its path using --model.", _modelPath);

        var workDir = Path.Combine(Path.GetTempPath(), "audio-transcription", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(workDir);

        try
        {
            var chunks = await _preprocessor.NormalizeAndSplitAsync(
                audioPath, workDir, _chunkDurationSeconds, cancellationToken);

            using var factory = WhisperFactory.FromPath(_modelPath);
            using var processor = factory.CreateBuilder()
                .WithLanguage(language)
                .Build();

            var segments = new List<TranscriptionSegment>();
            var fullText = new List<string>();
            var globalIndex = 1;

            for (var chunkIndex = 0; chunkIndex < chunks.Count; chunkIndex++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var offsetSeconds = (double)chunkIndex * _chunkDurationSeconds;

                await using var stream = File.OpenRead(chunks[chunkIndex]);
                await foreach (var item in processor.ProcessAsync(stream).WithCancellation(cancellationToken))
                {
                    var text = item.Text?.Trim();
                    if (string.IsNullOrWhiteSpace(text))
                        continue;

                    var start = Math.Max(0, offsetSeconds + item.Start.TotalSeconds);
                    var end = Math.Max(start, offsetSeconds + item.End.TotalSeconds);
                    segments.Add(new TranscriptionSegment(globalIndex++, start, end, text));
                    fullText.Add(text);
                }
            }

            var duration = segments.Count == 0 ? 0 : segments.Max(s => s.EndSeconds);
            return new TranscriptionResult(
                Path.GetFileName(audioPath), language, Path.GetFileName(_modelPath),
                DateTimeOffset.UtcNow, duration, string.Join(" ", fullText), segments);
        }
        finally
        {
            try
            {
                if (Directory.Exists(workDir))
                    Directory.Delete(workDir, recursive: true);
            }
            catch
            {
                // Best-effort cleanup; don't hide a transcription exception.
            }
        }
    }
}
