using System.Diagnostics;

namespace AudioTranscriptionAssessment.Services;

/// <summary>
/// Converts supported audio formats to mono, 16 kHz, 16-bit PCM WAV chunks.
/// FFmpeg must be installed and available on PATH.
/// </summary>
public sealed class FfmpegAudioPreprocessor
{
    public async Task<IReadOnlyList<string>> NormalizeAndSplitAsync(
        string inputPath,
        string workingDirectory,
        int chunkDurationSeconds,
        CancellationToken cancellationToken = default)
    {
        if (!File.Exists(inputPath))
            throw new FileNotFoundException("Audio file was not found.", inputPath);

        if (chunkDurationSeconds < 60)
            throw new ArgumentOutOfRangeException(nameof(chunkDurationSeconds), "Chunk duration must be at least 60 seconds.");

        Directory.CreateDirectory(workingDirectory);
        var outputPattern = Path.Combine(workingDirectory, "chunk_%04d.wav");

        var startInfo = new ProcessStartInfo
        {
            FileName = "ffmpeg",
            RedirectStandardError = true,
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };

        string[] args =
        [
            "-hide_banner", "-loglevel", "error", "-y",
            "-i", Path.GetFullPath(inputPath),
            "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
            "-f", "segment", "-segment_time", chunkDurationSeconds.ToString(),
            "-reset_timestamps", "1", outputPattern
        ];

        foreach (var arg in args)
            startInfo.ArgumentList.Add(arg);

        using var process = new Process { StartInfo = startInfo };
        process.Start();

        // Drain both streams concurrently to avoid process pipe deadlocks.
        var stderrTask = process.StandardError.ReadToEndAsync(cancellationToken);
        var stdoutTask = process.StandardOutput.ReadToEndAsync(cancellationToken);
        await process.WaitForExitAsync(cancellationToken);
        var stderr = await stderrTask;
        _ = await stdoutTask;

        if (process.ExitCode != 0)
            throw new InvalidOperationException($"FFmpeg failed with exit code {process.ExitCode}: {stderr}");

        var chunks = Directory.GetFiles(workingDirectory, "chunk_*.wav")
            .OrderBy(path => path, StringComparer.Ordinal)
            .ToArray();

        if (chunks.Length == 0)
            throw new InvalidOperationException("FFmpeg completed but produced no audio chunks.");

        return chunks;
    }
}
